package org.example;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
public class Library {

    private List<Book> books;

    // Constructor
    public Library() {
        this.books = new ArrayList<>();
    }


    public void addBook(Book book) {
        books.add(book);
        System.out.println("Book added: " + book.getTitle());
    }

    public void removeBook(Book book) {
        if (books.remove(book)) {
            System.out.println("Book removed: " + book.getTitle());
        } else {
            System.out.println("Book not found: " + book.getTitle());
        }
    }

    public List<Book> getBooksByAuthor(String author) {
        List<Book> booksByAuthor = new ArrayList<>();
        for (Book book : books) {
            if (book.getAuthor().equalsIgnoreCase(author)) {
                booksByAuthor.add(book);
            }
        }
        return booksByAuthor;
    }

    public List<Book> getBooksByYear(int year) {
        List<Book> booksByYear = new ArrayList<>();
        for (Book book : books) {
            if (book.getYear() == year) {
                booksByYear.add(book);
            }
        }
        return booksByYear;
    }
    public List<Book> getAllBooks() {
        return new ArrayList<>(books); // Retorna una copia de la lista de libros
    }
}
