package org.example;
import java.util.List;
import java.util.Scanner;

public class LibrarySystem {
    private Library library;
    private Scanner scanner;

    // Constructor
    public LibrarySystem() {
        this.library = new Library();
        this.scanner = new Scanner(System.in);
    }

    public void start() {
        System.out.println("Welcome to the Library!");
        System.out.println("Commands: add, remove, search author, search year, list, exit");

        String command;
        while (true) {
            System.out.print("Enter a command: ");
            command = scanner.nextLine();

            switch (command.toLowerCase()) {
                case "add":
                    addBook();
                    break;

                case "remove":
                    removeBook();
                    break;

                case "search author":
                    searchBooksByAuthor();
                    break;

                case "search year":
                    searchBooksByYear();
                    break;

                case "list":
                    listAllBooks();
                    break;

                case "exit":
                    System.out.println("Exiting the library system.");
                    scanner.close();
                    return;

                default:
                    System.out.println("Unknown command. Please try again.");
            }
        }
    }

    //  agregar un libro
    private void addBook() {
        System.out.print("Enter book title: ");
        String title = scanner.nextLine();
        System.out.print("Enter book author: ");
        String author = scanner.nextLine();
        System.out.print("Enter year of publication: ");
        int year = Integer.parseInt(scanner.nextLine());

        Book newBook = new Book(title, author, year);
        library.addBook(newBook);
    }

    // eliminar un libro
    private void removeBook() {
        System.out.print("Enter book title to remove: ");
        String titleToRemove = scanner.nextLine();
        List<Book> allBooks = library.getAllBooks();
        Book bookToRemove = null;

        for (Book book : allBooks) {
            if (book.getTitle().equalsIgnoreCase(titleToRemove)) {
                bookToRemove = book;
                break;
            }
        }

        if (bookToRemove != null) {
            library.removeBook(bookToRemove);
        } else {
            System.out.println("Book not found.");
        }
    }

    // buscar libros por autor
    private void searchBooksByAuthor() {
        System.out.print("Enter author name: ");
        String searchAuthor = scanner.nextLine();
        List<Book> booksByAuthor = library.getBooksByAuthor(searchAuthor);
        System.out.println("Books by " + searchAuthor + ":");
        if (booksByAuthor.isEmpty()) {
            System.out.println("No books found.");
        } else {
            for (Book book : booksByAuthor) {
                System.out.println(book);
            }
        }
    }

    //  buscar libros por año
    private void searchBooksByYear() {
        System.out.print("Enter year: ");
        int searchYear = Integer.parseInt(scanner.nextLine());
        List<Book> booksByYear = library.getBooksByYear(searchYear);
        System.out.println("Books published in " + searchYear + ":");
        if (booksByYear.isEmpty()) {
            System.out.println("No books found.");
        } else {
            for (Book book : booksByYear) {
                System.out.println(book);
            }
        }
    }

    //  listar todos los libros
    private void listAllBooks() {
        System.out.println("All books in the library:");
        List<Book> allBooksInLibrary = library.getAllBooks();
        if (allBooksInLibrary.isEmpty()) {
            System.out.println("No books in the library.");
        } else {
            for (Book book : allBooksInLibrary) {
                System.out.println(book);
            }
        }
    }
}