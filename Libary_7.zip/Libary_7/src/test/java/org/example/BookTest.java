package org.example;

import org.junit.Test;
import static org.junit.Assert.*;
public class BookTest {

    @Test
    public void testBookCreation() {
        Book book = new Book("The Way of Kings", "Brandon Sanderson", 2010);

        assertEquals("The Way of Kings", book.getTitle());
        assertEquals("Brandon Sanderson", book.getAuthor());
        assertEquals(2010, book.getYear());
    }

    @Test
    public void testBookSetters() {
        Book book = new Book("Initial Title", "Author", 2000);
        book.setTitle("Updated Title");
        book.setAuthor("Updated Author");
        book.setYear(2021);

        assertEquals("Updated Title", book.getTitle());
        assertEquals("Updated Author", book.getAuthor());
        assertEquals(2021, book.getYear());
    }
}