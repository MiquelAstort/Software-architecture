package org.example;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class LibraryTest {
    private Library library;

    @Before
    public void setUp() {
        library = new Library();
        library.addBook(new Book("The Way of Kings", "Brandon Sanderson", 2010));
        library.addBook(new Book("Mistborn", "Brandon Sanderson", 2006));
        library.addBook(new Book("The Hobbit", "J.R.R. Tolkien", 1937));
    }

    @Test
    public void testAddBook() {
        assertEquals(3, library.getAllBooks().size());
        library.addBook(new Book("1984", "George Orwell", 1949));
        assertEquals(4, library.getAllBooks().size());
    }

    @Test
    public void testRemoveBook() {
        assertEquals(3, library.getAllBooks().size());
        library.removeBook(new Book("Mistborn", "Brandon Sanderson", 2006));
        assertEquals(2, library.getAllBooks().size());
    }

    @Test
    public void testGetBooksByAuthor() {
        List<Book> sandersonBooks = library.getBooksByAuthor("Brandon Sanderson");
        assertEquals(2, sandersonBooks.size());

        List<Book> tolkienBooks = library.getBooksByAuthor("J.R.R. Tolkien");
        assertEquals(1, tolkienBooks.size());
    }

    @Test
    public void testGetBooksByYear() {
        List<Book> booksFrom2010 = library.getBooksByYear(2010);
        assertEquals(1, booksFrom2010.size());

        List<Book> booksFrom2006 = library.getBooksByYear(2006);
        assertEquals(1, booksFrom2006.size());
    }

    @Test
    public void testGetAllBooks() {
        List<Book> allBooks = library.getAllBooks();
        assertEquals(3, allBooks.size());
    }
}