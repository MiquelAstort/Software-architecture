//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Person[] persons = {new Person("Miquel", "Astort"), new Person("Quim", "Astort"), new Person("Guillem", "Nuñez"), new Person("Alex", "Marquez"), new Person("Ignasi", "Abad") // creamos un array de classe Person[] con 5 name y 5 surname
        };
        Rectangle[] rectangles = {new Rectangle(3,1), new Rectangle(3, 8), new Rectangle(5, 6), new Rectangle(9, 2), new Rectangle(3, 8)
        };
        /*
        //creamos Sorter
        Sorter sorter = new Sorter();
        // Ordenar el array de Person
        sorter.sortPersons(persons);

        // Imprimir el array ordenado
        System.out.println("list of persons:");
        for (Person person : persons) {
            person.printFullName();
        }*/
        // creamos Sorter
        Sorter sorter = new Sorter();

        // Ordenar y mostrar Persons
        sorter.sort(persons);
        System.out.println("list of persons:");
        for (Person person : persons) {
            person.printFullName();
        }

        // Ordenar y mostrar Rectangles
        sorter.sort(rectangles);
        System.out.println("list of rectangles by area:");
        for (Rectangle rectangle : rectangles) {
            System.out.println( " Area: " + rectangle.area());
        }
    }

}
