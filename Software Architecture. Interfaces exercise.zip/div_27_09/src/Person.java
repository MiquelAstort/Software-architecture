public class Person implements SorterKey  {
    public String name;
    public String surname;

    // Constructor
    public Person(String name, String surname) {
        this.name = name;
        this.surname = surname;
    }
    //function
    public void printFullName() {
        System.out.println(surname + " " + name);
    }
    @Override
    public String getSortKey() {
        // Sort by surname first, then by name if surnames are equal
        return surname + name;
    }

}
