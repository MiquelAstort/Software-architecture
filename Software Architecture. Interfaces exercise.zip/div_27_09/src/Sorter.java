public class Sorter {
    /*public void sortPersons(Person[] persons) {
        int n = persons.length;
        boolean swapped;         // indicar si se realizó un intercambio eso lo hacemos para hacer el codigo mas eficiente y no tener que recorrer siempre los bucles hasta el final
        for (int i = 0; i < n - 1; i++) {//bucle que nos hace hacer las compraciones tantas veces como posiciones tenga el array
            swapped = false;  // Inicializar la variable swapped en false para cada pasada
            for (int j = 0; j < n - i - 1; j++) { //bucle que recorre todo el array de personas
                // Comparar por apellido primero
                int surnameComparison = persons[j].surname.compareTo(persons[j + 1].surname);
                // surnameCoparison deveuele un valor negativ0 si el apellido de persons[j] es menor, cero si son iguales, y un valor positivo si es mayor que persons [j+1]
                if (surnameComparison == 0) {
                    // Si los apellidos son iguales, comparar por nombre
                    surnameComparison = persons[j].name.compareTo(persons[j + 1].name);
                    //lo mismo pero con el nobre
                }

                if (surnameComparison > 0) {
                    // Intercambiar los elementos si el actual es mayor que el siguiente
                    Person temp = persons[j];
                    persons[j] = persons[j + 1];
                    persons[j + 1] = temp;
                    swapped = true;  // Se realizó un intercambio
                }
            }
            // Si no se intercambiaron elementos, el array ya está ordenado
            if (!swapped) break;
        }
    }*/
    public void sort(SorterKey[] items) {
        int n = items.length;
        boolean swapped;
        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - i - 1; j++) {
                // Comparar por el sort key de cada elemento que emos entrado en la interface para Peroson  name+ surname y para rectangle area
                if (items[j].getSortKey().compareTo(items[j + 1].getSortKey()) > 0) {
                    // sie el resultado de compare to es mayor a 0 intercanviamos posiciones
                    SorterKey temp = items[j];
                    items[j] = items[j + 1];
                    items[j + 1] = temp;
                    swapped = true;
                }
            }
            if (swapped == false) break;
        }
    }
}
