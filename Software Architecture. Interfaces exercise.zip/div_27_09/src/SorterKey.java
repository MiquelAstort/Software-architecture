public interface SorterKey {
    Comparable getSortKey();
}
