//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.ArrayList;
import java.util.List;
public class Main {
    public static void main(String[] args) {
        Person person1 = new Person("123", "Miquel", "Astort", "aribau 256");
        Person person2 = new Person("567", "Quim", "Astort", "Aribau 256");
        Car car1 = new Car("ABC123", "Citroen", "Corza", 150, Car.FuelType.PETROL);
        Car car2 = new Car("DEF456", "Audi", "MG", 160, Car.FuelType.PETROL);
        Motorcycle moto1 = new Motorcycle("GHI789", "Yamaha", "R1", 600);
        Motorcycle moto2 = new Motorcycle("JKL101", "Yamaha", "R2", 1200);

        person1.addVehicle(car1);
        person1.addVehicle(moto1);
        person2.addVehicle(moto2);
        // lista peronas
        List<Person> people = new ArrayList<>();
        people.add(person1);
        people.add(person2);
        car1.transferOwner(person2);
        // Lista de vehículos
        List<Vehicle> allVehicles = new ArrayList<>();
        allVehicles.add(car1);
        allVehicles.add(moto1);
        allVehicles.add(moto2);
        allVehicles.add(car2); // car2 no está asignado
        //Imprimir vehiculos no assigandos
        System.out.println("Unassigned Vehicles:");
        double totalUnassignedTaxes = 0;
        for (Vehicle v : allVehicles) {
            if (v.getOwner() == null) {
                System.out.println(v + " - Tax: " + v.calculateTax() + "€");
                totalUnassignedTaxes += v.calculateTax();
            }
        }
        // imprimir personas + vehiculos
        for (Person person : people) {
            System.out.println(person);
            for (Vehicle vehicle : person.getVehicles()) {
                System.out.println(vehicle + " - Tax: " + vehicle.calculateTax() + "€");
            }
            System.out.println("Total Taxes for " + person.getName() + ": " + person.calculateTotalTaxes() + "€\n");
        }
        System.out.println("\nTotal Unassigned Taxes: " + totalUnassignedTaxes + "€");
        double totalTaxes= 0;
        for (Vehicle vehicle : allVehicles) {
            totalTaxes += vehicle.calculateTax();
        }
        System.out.println("\nTotal Taxes: " + totalTaxes + "€");

    }


}