public class Car extends Vehicle {
    public double co2Emissions;
    public FuelType fuelType;

    public enum FuelType {
        PETROL, DIESEL, HYBRID
    }

    public Car(String plateNumber, String maker, String model, double co2Emissions, FuelType fuelType) {
        super(plateNumber, maker, model);
        this.co2Emissions = co2Emissions;
        this.fuelType = fuelType;  // Sin validación ni conversión
    }


    @Override
    public double calculateTax() {
        double rate = 0;
        switch (fuelType) {
            case PETROL:
                rate = 1.4;
                break;
            case DIESEL:
                rate = 1.8;
                break;
            case HYBRID:
                rate = 1.2;
                break;
        }
        return co2Emissions * rate;
    }
}
