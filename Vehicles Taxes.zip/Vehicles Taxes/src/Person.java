import java.util.List;
import java.util.ArrayList;
public class Person {
    public String licenseNumber;
    public String name;
    public String surname;
    public String address;

    public List<Vehicle> vehicles;
    public Person(String licenseNumber, String name, String surname, String address) {
        this.licenseNumber = licenseNumber;
        this.name = name;
        this.surname = surname;
        this.address = address;
        this.vehicles = new ArrayList<>();  // Inicializa la lista de vehículos
    }
    public String getLicenseNumber() {
        return licenseNumber;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getAddress() {
        return address;
    }
    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
        vehicle.setOwner(this);
    }

    public void removeVehicle(Vehicle vehicle) {
        vehicles.remove(vehicle);
        vehicle.setOwner(null);
    }
    public List<Vehicle> getVehicles() {
        return vehicles;
    }
    public double calculateTotalTaxes() {
        return vehicles.stream().mapToDouble(Vehicle::calculateTax).sum();
    }

    @Override
    public String toString() {
        return name + " " + surname + " (" + licenseNumber + ")";
    }

}

