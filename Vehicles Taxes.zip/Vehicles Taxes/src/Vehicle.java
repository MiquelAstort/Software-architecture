public abstract class Vehicle {
    private String plateNumber;
    private String maker;
    private String model;
    protected Person owner;
    public Vehicle(String plateNumber, String maker, String model) {
        this.plateNumber = plateNumber;
        this.maker = maker;
        this.model = model;
    }
    public String getPlateNumber() {
        return plateNumber;
    }

    public String getMaker() {
        return maker;
    }

    public String getModel() {
        return model;
    }
    public Person getOwner() {
        return owner;
    }

    public void setOwner(Person owner) {
        this.owner = owner;
    }

    public void transferOwner(Person newOwner) {

        this.owner.removeVehicle(this);
        this.owner = newOwner;
        newOwner.addVehicle(this);

    }

    public abstract double calculateTax();

    @Override
    public String toString() {
        return maker + " " + model + " (" + plateNumber + ")";
    }
}
