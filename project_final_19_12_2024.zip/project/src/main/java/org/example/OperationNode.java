package org.example;

import java.util.Map;
import java.util.List;

public class OperationNode implements Node {
    private final String operator;
    private final List<Node> operands;

    public OperationNode(String operator, List<Node> operands) {
        this.operator = operator;
        this.operands = operands;
    }

    public String getOperator() {
        return operator;
    }

    public List<Node> getOperands() {
        return operands;
    }

    @Override
    public double evaluate(Map<String, Cell> cellMap) {
        switch (operator) {
            case "+":
                return operands.get(0).evaluate(cellMap) + operands.get(1).evaluate(cellMap);
            case "-":
                return operands.get(0).evaluate(cellMap) - operands.get(1).evaluate(cellMap);
            case "*":
                return operands.get(0).evaluate(cellMap) * operands.get(1).evaluate(cellMap);
            case "/":
                return operands.get(0).evaluate(cellMap) / operands.get(1).evaluate(cellMap);
            default:
                throw new IllegalArgumentException("Unknown operator: " + operator);
        }
    }
}
