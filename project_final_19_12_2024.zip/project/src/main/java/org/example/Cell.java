package org.example;
import java.util.Map;
public abstract class Cell {
    protected String coordinate;
    protected String content;

    public Cell(String coordinate, String content) {
        this.coordinate = coordinate;
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public abstract Object evaluate(Map<String, Cell> cellMap);
}
