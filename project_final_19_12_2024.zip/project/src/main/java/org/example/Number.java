package org.example;
import java.util.Map;
public class Number extends Cell {
    private double value;

    public Number(String coordinate, double value) {
        super(coordinate, Double.toString(value));
        this.value = value;
    }

    public double getValue() {
        return value;
    }

    @Override
    public Double evaluate(Map<String, Cell> cellMap) {
        return value;
    }
}
