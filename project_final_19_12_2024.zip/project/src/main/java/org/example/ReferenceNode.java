package org.example;

import java.util.Map;

public class ReferenceNode implements Node {
    private final String coordinate;

    public ReferenceNode(String coordinate) {
        this.coordinate = coordinate;
    }

    public String getCoordinate() {
        return coordinate;
    }

    @Override
    public double evaluate(Map<String, Cell> cellMap) {
        if (!cellMap.containsKey(coordinate)) {
            throw new IllegalStateException("Cell " + coordinate + " does not exist.");
        }
        Cell referencedCell = cellMap.get(coordinate);

        if (referencedCell instanceof Formula) {
            return ((Formula) referencedCell).evaluate(cellMap);
        }

        if (referencedCell instanceof Number) {
            return ((Number) referencedCell).getValue();
        } else {
            throw new IllegalStateException("Referenced cell " + coordinate + " is not numeric or is empty.");
        }
    }


}
