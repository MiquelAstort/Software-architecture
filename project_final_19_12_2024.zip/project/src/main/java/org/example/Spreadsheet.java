
package org.example;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Spreadsheet {
    private final Map<String, Cell> cells;
    private final Format format;

    public Spreadsheet() {
        cells = new HashMap<>();
        format = new Format();
    }

    public void addCell(String coordinate, Cell cell) {
        cells.put(coordinate, cell);
    }

    public void editCellContent(String coordinate, String content) {
        addCellContent(coordinate, content);
    }

    public void addCellContent(String coordinate, String content) {

        if (content != null && content.startsWith("=")) {

            Cell formulaCell = new Formula(coordinate, content);
            cells.put(coordinate, formulaCell);
        } else {
            try {
                double value = Double.parseDouble(content);
                Cell numberCell = new Number(coordinate, value);
                cells.put(coordinate, numberCell);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("The content of the cell is not a valid number.");
            }
        }
    }

    public String viewCellContent(String coordinate) {
        if (cells.containsKey(coordinate)) {
            Cell cell = cells.get(coordinate);
            if (cell instanceof Formula) {

                return String.valueOf(((Formula) cell).evaluate(cells));
            }
            return cell.getContent();
        }
        return "";
    }

    public void detectCircularDependency() {
        Set<String> visited = new HashSet<>();
        Set<String> stack = new HashSet<>();

        for (String coordinate : cells.keySet()) {
            if (!visited.contains(coordinate)) {
                detectCycle(coordinate, visited, stack);
            }
        }
    }

    private void detectCycle(String coordinate, Set<String> visited, Set<String> stack) {
        if (stack.contains(coordinate)) {
            throw new IllegalStateException("Circular dependency detected at cell: " + coordinate);
        }

        if (!visited.contains(coordinate)) {
            visited.add(coordinate);
            stack.add(coordinate);

            Cell cell = cells.get(coordinate);
            if (cell instanceof Formula) {
                Formula formula = (Formula) cell;
                Node rootNode = formula.getRootNode();
                findDependencies(rootNode, stack);
            }

            stack.remove(coordinate);
        }
    }

    private void findDependencies(Node node, Set<String> stack) {
        if (node instanceof ReferenceNode) {
            String ref = ((ReferenceNode) node).getCoordinate();
            detectCycle(ref, new HashSet<>(), stack);
        } else if (node instanceof OperationNode) {
            for (Node operand : ((OperationNode) node).getOperands()) {
                findDependencies(operand, stack);
            }
        }
    }

    public void evaluateFormulas() {
        for (Map.Entry<String, Cell> entry : cells.entrySet()) {
            Cell cell = entry.getValue();
            if (cell instanceof Formula) {
                Formula formulaCell = (Formula) cell;
                String result = String.valueOf(formulaCell.evaluate(cells));
                cell.setContent(result);
            }
        }
    }

    public void saveSpreadsheet(String path) {
        format.save(this, path);
    }

    public void loadSpreadsheet(String path) {
        format.load(this, path);
    }

    public Map<String, Cell> getAllCells() {
        return cells;
    }

    public void printSpreadsheetAsTable() {
        // Determine the table's limits
        int maxRow = 0;
        char maxColumn = 'A';

        for (String coordinate : cells.keySet()) {
            int row = Integer.parseInt(coordinate.substring(1));
            char column = coordinate.charAt(0);
            if (row > maxRow) maxRow = row;
            if (column > maxColumn) maxColumn = column;
        }


        System.out.print("    ");
        for (char column = 'A'; column <= maxColumn; column++) {
            System.out.print(column + "      ");
        }
        System.out.println();


        for (int row = 1; row <= maxRow; row++) {
            System.out.print(row + "  ");
            for (char column = 'A'; column <= maxColumn; column++) {
                String coordinate = "" + column + row;
                String content = cells.containsKey(coordinate) ? cells.get(coordinate).getContent() : "";
                System.out.printf("%-6s ", content);
            }
            System.out.println();
        }
    }



}
