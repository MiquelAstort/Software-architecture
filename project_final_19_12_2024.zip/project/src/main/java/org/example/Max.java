package org.example;
import java.util.List;
import java.util.Map;

public class Max extends Function {
    public Max(String coordinate, String range) {
        super(coordinate, range);
    }

    @Override
    public Double evaluate(Map<String, Cell> cellMap) {
        RangeNode rangeNode = new RangeNode(range);
        List<Double> values = rangeNode.getValues(cellMap);
        return values.stream().max(Double::compare).orElseThrow(() -> new IllegalStateException("No values in range"));
    }
}


