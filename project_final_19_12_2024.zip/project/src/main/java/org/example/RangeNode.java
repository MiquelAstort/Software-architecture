package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class RangeNode implements Node {
    private final String startCell;
    private final String endCell;

    public RangeNode(String range) {
        String[] parts = range.split(":");
        if (parts.length != 2) {
            throw new IllegalArgumentException("Invalid range format: " + range);
        }
        this.startCell = parts[0];
        this.endCell = parts[1];
    }

    @Override
    public double evaluate(Map<String, Cell> cellMap) {
        throw new UnsupportedOperationException("RangeNode evaluation needs a list of values.");
    }

    public List<Double> getValues(Map<String, Cell> cellMap) {
        List<Double> values = new ArrayList<>();

        char startColumn = startCell.charAt(0);
        int startRow = Integer.parseInt(startCell.substring(1));
        char endColumn = endCell.charAt(0);
        int endRow = Integer.parseInt(endCell.substring(1));

        for (char column = startColumn; column <= endColumn; column++) {
            for (int row = startRow; row <= endRow; row++) {
                String cellCoordinate = column + String.valueOf(row);
                if (cellMap.containsKey(cellCoordinate)) {
                    Cell cell = cellMap.get(cellCoordinate);
                    if (cell instanceof Number) {
                        values.add(((Number) cell).getValue());
                    } else if (cell instanceof Formula) {
                        values.add(((Formula) cell).evaluate(cellMap));
                    }
                }
            }
        }
        return values;
    }
}
