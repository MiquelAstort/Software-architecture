package org.example;
import java.util.Map;
public class NumberNode implements Node {
    private final double value;

    public NumberNode(double value) {
        this.value = value;
    }

    @Override
    public double evaluate(Map<String, Cell> cellMap) {
        return value;
    }
}

