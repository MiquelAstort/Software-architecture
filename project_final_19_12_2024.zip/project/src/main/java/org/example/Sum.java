package org.example;

import java.util.Map;

public class Sum extends Function {
    public Sum(String coordinate, String range) {
        super(coordinate, range);
    }

    @Override
    public Double evaluate(Map<String, Cell> cellMap) {
        return 0.0;
    }
}