package org.example;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;
import java.util.Scanner;

public class Format {

    public void save(Spreadsheet spreadsheet, String path) {
        try (FileWriter writer = new FileWriter(new File(path))) {
            for (Map.Entry<String, Cell> entry : spreadsheet.getAllCells().entrySet()) {
                writer.write(entry.getKey() + "=" + entry.getValue().getContent() + ";");
            }
            System.out.println("Hoja de cálculo guardada  " + path);
        } catch (IOException e) {
            System.out.println("Error al guardar la hoja de cálculo: " + e.getMessage());
        }
    }

    public void load(Spreadsheet spreadsheet, String path) {
        try (Scanner scanner = new Scanner(new File(path))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] cells = line.split(";");
                for (String cellData : cells) {
                    if (!cellData.isEmpty()) {
                        String[] parts = cellData.split("=");
                        String coordinate = parts[0];
                        String content = parts[1];
                        spreadsheet.addCellContent(coordinate, content);
                    }
                }
            }
            System.out.println("Hoja de cálculo cargada  " + path);
        } catch (IOException e) {
            System.out.println("Error al cargar la hoja de cálculo: " + e.getMessage());
        }
    }
}
