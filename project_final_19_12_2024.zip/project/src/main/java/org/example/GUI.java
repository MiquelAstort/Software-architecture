package org.example;

import java.util.Scanner;

public class GUI {
    private final Spreadsheet spreadsheet;
    private final Scanner scanner;

    public GUI() {
        this.spreadsheet = new Spreadsheet();
        this.scanner = new Scanner(System.in);
    }

    public void start() {
        while (true) {
            showMenu();
            String option = scanner.nextLine();
            processOption(option);
        }
    }

    private void showMenu() {
        System.out.println("1. Add/Edit Cell Content");
        System.out.println("2. View Cell Content");
        System.out.println("3. Save Spreadsheet");
        System.out.println("4. Load Spreadsheet");
        System.out.println("5. Print Spreadsheet");
        System.out.println("6. Exit");
        System.out.print("Choose an option: ");
    }

    private void processOption(String option) {
        switch (option) {
            case "1":
                addEditCellContent();
                break;
            case "2":
                viewCellContent();
                break;
            case "3":
                saveSpreadsheet();
                break;
            case "4":
                loadSpreadsheet();
                break;
            case "5":
                spreadsheet.printSpreadsheetAsTable();
                break;
            case "6":
                System.exit(0);
            default:
                System.out.println("Invalid option.");
        }
    }

    private void addEditCellContent() {
        System.out.print("Enter cell coordinate (e.g., A1): ");
        String coordinate = scanner.nextLine();
        System.out.print("Enter cell content: ");
        String content = scanner.nextLine();
        spreadsheet.editCellContent(coordinate, content);
    }

    private void viewCellContent() {
        System.out.print("Enter cell coordinate (e.g., A1): ");
        String coordinate = scanner.nextLine();
        System.out.println("Cell content: " + spreadsheet.viewCellContent(coordinate));
    }

    private void saveSpreadsheet() {
        System.out.print("Enter file path to save: ");
        String filePath = scanner.nextLine();
        spreadsheet.saveSpreadsheet(filePath);
    }

    private void loadSpreadsheet() {
        System.out.print("Enter file path to load: ");
        String filePath = scanner.nextLine();
        spreadsheet.loadSpreadsheet(filePath);
    }
}
