package org.example;
import java.util.Map;
public interface Node {
    double evaluate(Map<String, Cell> cellMap);
}

