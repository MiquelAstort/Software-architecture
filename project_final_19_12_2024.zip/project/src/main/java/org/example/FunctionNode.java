package org.example;

import java.util.List;
import java.util.Map;

public class FunctionNode implements Node {
    private final String functionName;
    private final List<Node> arguments;

    public FunctionNode(String functionName, List<Node> arguments) {
        this.functionName = functionName;
        this.arguments = arguments;
    }

    @Override
    public double evaluate(Map<String, Cell> cellMap) {
        List<Double> values = arguments.stream()
                .flatMap(arg -> {
                    if (arg instanceof RangeNode) {
                        return ((RangeNode) arg).getValues(cellMap).stream();
                    }
                    return List.of(arg.evaluate(cellMap)).stream();
                })
                .toList();

        switch (functionName) {
            case "MAX":
                return values.stream().max(Double::compare).orElseThrow(() -> new IllegalStateException("No values to evaluate"));
            case "MIN":
                return values.stream().min(Double::compare).orElseThrow(() -> new IllegalStateException("No values to evaluate"));
            case "PROM":
                return values.stream().mapToDouble(Double::doubleValue).average().orElseThrow(() -> new IllegalStateException("No values to evaluate"));
            default:
                throw new IllegalArgumentException("Unknown function: " + functionName);
        }
    }
}
