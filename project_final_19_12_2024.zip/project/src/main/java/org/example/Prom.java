package org.example;
import java.util.List;
import java.util.Map;

public class Prom extends Function {
    public Prom(String coordinate, String range) {
        super(coordinate, range);
    }
    @Override
    public Double evaluate(Map<String, Cell> cellMap) {
        RangeNode rangeNode = new RangeNode(range);
        List<Double> values = rangeNode.getValues(cellMap);
        return values.stream().mapToDouble(Double::doubleValue).average().orElseThrow(() -> new IllegalStateException("No values in range"));
    }

}
