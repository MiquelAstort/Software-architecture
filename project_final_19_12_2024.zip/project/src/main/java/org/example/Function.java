package org.example;
import java.util.Map;
public abstract class Function extends Cell {
    protected String range;

    public Function(String coordinate, String range) {
        super(coordinate, "=" + range);
        this.range = range;
    }


    public abstract Double evaluate(Map<String, Cell> cellMap);
}

