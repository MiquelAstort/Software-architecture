package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class Parser {
    public Node parse(String formula) {
        String[] tokens = tokenize(formula);
        Stack<Node> output = new Stack<>();
        Stack<String> operators = new Stack<>();

        for (int i = 0; i < tokens.length; i++) {
            String token = tokens[i];
            if (isRange(token)) {
                output.push(new RangeNode(token));
            } else if (isNumber(token)) {
                output.push(new NumberNode(Double.parseDouble(token)));
            } else if (isCellReference(token)) {
                output.push(new ReferenceNode(token));
            } else if (token.equals(":")) {
                if (output.isEmpty()) {
                    throw new IllegalArgumentException("Invalid range: missing start of range before ':'");
                }
                Node startNode = output.pop();
                if (!(startNode instanceof ReferenceNode)) {
                    throw new IllegalArgumentException("Invalid range: ':' must follow a cell reference");
                }
                if (i + 1 >= tokens.length || !isCellReference(tokens[i + 1])) {
                    throw new IllegalArgumentException("Invalid range: missing end of range after ':'");
                }
                String startCell = ((ReferenceNode) startNode).getCoordinate();
                String endCell = tokens[++i];
                output.push(new RangeNode(startCell + ":" + endCell));
            } else if (isFunction(token)) {
                operators.push(token);
            } else if (isOperator(token)) {
                while (!operators.isEmpty() && hasHigherPrecedence(operators.peek(), token)) {
                    popOperatorToOutput(operators, output);
                }
                operators.push(token);
            } else if (token.equals("(")) {
                operators.push(token);
            } else if (token.equals(";")) {
            } else if (token.equals(")")) {
                while (!operators.isEmpty() && !operators.peek().equals("(")) {
                    popOperatorToOutput(operators, output);
                }
                if (!operators.isEmpty() && operators.peek().equals("(")) {
                    operators.pop();
                }
                if (!operators.isEmpty() && isFunction(operators.peek())) {
                    String functionName = operators.pop();
                    List<Node> arguments = new ArrayList<>();
                    while (!output.isEmpty() && !(output.peek() instanceof FunctionNode)) {
                        arguments.add(0, output.pop());
                    }
                    output.push(new FunctionNode(functionName, arguments));
                }
            } else {
                throw new IllegalArgumentException("Unknown token: " + token);
            }
        }

        while (!operators.isEmpty()) {
            popOperatorToOutput(operators, output);
        }

        if (output.isEmpty()) {
            throw new IllegalArgumentException("Invalid formula: " + formula);
        }

        return output.pop();
    }

    private String[] tokenize(String formula) {

        String spacedFormula = formula
                .replace("(", " ( ")
                .replace(")", " ) ")
                .replace("+", " + ")
                .replace("-", " - ")
                .replace("*", " * ")
                .replace("/", " / ")
                .replace(";", " ; ")
                .replace(":", " : ");

        return spacedFormula.trim().split("\\s+");
    }

    private boolean isNumber(String token) {
        return token.matches("-?\\d+(\\.\\d+)?");
    }

    private boolean isCellReference(String token) {
        return token.matches("[A-Z]+[0-9]+");
    }

    private boolean isRange(String token) {
        // Detecta rangos como B1:C3
        return token.matches("[A-Z]+[0-9]+:[A-Z]+[0-9]+");
    }

    private boolean isOperator(String token) {
        return token.equals("+") || token.equals("-") || token.equals("*") || token.equals("/");
    }

    private boolean isFunction(String token) {
        return token.matches("MAX|MIN|PROM");
    }

    private boolean hasHigherPrecedence(String op1, String op2) {
        return getPrecedence(op1) >= getPrecedence(op2);
    }

    private int getPrecedence(String operator) {
        switch (operator) {
            case "+":
            case "-":
                return 1;
            case "*":
            case "/":
                return 2;
            default:
                return 0;
        }
    }

    private void popOperatorToOutput(Stack<String> operators, Stack<Node> output) {
        String operator = operators.pop();
        if (output.size() < 2) {
            throw new IllegalArgumentException("Not enough operands for operator: " + operator);
        }
        Node right = output.pop();
        Node left = output.pop();
        output.push(new OperationNode(operator, List.of(left, right)));
    }
}
