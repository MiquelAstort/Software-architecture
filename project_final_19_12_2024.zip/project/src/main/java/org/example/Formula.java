package org.example;

import java.util.Map;

public class Formula extends Cell {
    private final Node rootNode;

    public Formula(String coordinate, String formula) {
        super(coordinate, formula);
        Parser parser = new Parser();
        this.rootNode = parser.parse(formula.substring(1));
    }

    @Override
    public Double evaluate(Map<String, Cell> cellMap) {
        return rootNode.evaluate(cellMap);
    }

    public Node getRootNode() {
        return rootNode;
    }
}
