package org.example;

public class Prom extends Function {
    public Prom(String coordinate, String range) {
        super(coordinate, range);
    }

    @Override
    public Double evaluate() {
        return 0.0; // Evaluación futura
    }
}