package org.example;

public class Formula extends Cell {
    public Formula(String coordinate, String formula) {
        super(coordinate, formula);
    }

    @Override
    public String evaluate() {
        return content; // Fórmulas no evaluadas
    }
}