package org.example;
import org.example.Format;
import org.example.Formula;
import org.example.Number;
import org.example.Text;
import java.util.HashMap;
import java.util.Map;

public class Spreadsheet {
    private Map<String, Cell> cells;
    private Format format;

    public Spreadsheet() {
        cells = new HashMap<>();
        format = new Format();
    }

    public void addCell(String coordinate, Cell cell) {
        cells.put(coordinate, cell);
    }

    public void editCellContent(String coordinate, String content) {
        if (cells.containsKey(coordinate)) {
            cells.get(coordinate).setContent(content);
        } else {
            addCellContent(coordinate, content);
        }
    }

    public void addCellContent(String coordinate, String content) {
        Cell cell;
        if (content.startsWith("=")) {
            cell = new Formula(coordinate, content); // Fórmulas no evaluadas
        } else {
            try {
                double numericValue = Double.parseDouble(content);
                cell = new Number(coordinate, numericValue);
            } catch (NumberFormatException e) {
                cell = new Text(coordinate, content);
            }
        }
        addCell(coordinate, cell);
    }

    public String viewCellContent(String coordinate) {
        return cells.containsKey(coordinate) ? cells.get(coordinate).getContent() : "";
    }

    public void detectCircularDependency() {

    }

    public void saveSpreadsheet(String path) {
        format.save(this, path);
    }

    public void loadSpreadsheet(String path) {
        format.load(this, path);
    }

    public Map<String, Cell> getAllCells() {
        return cells;
    }
}

