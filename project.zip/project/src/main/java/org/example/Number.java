package org.example;

public class Number extends Cell {
    private double value;

    public Number(String coordinate, double value) {
        super(coordinate, Double.toString(value));
        this.value = value;
    }

    @Override
    public Double evaluate() {
        return value;
    }
}