package org.example;

public class Max extends Function {
    public Max(String coordinate, String range) {
        super(coordinate, range);
    }

    @Override
    public Double evaluate() {
        return 0.0; // Evaluación futura
    }
}
