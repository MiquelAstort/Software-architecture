package org.example;

public class Sum extends Function {
    public Sum(String coordinate, String range) {
        super(coordinate, range);
    }

    @Override
    public Double evaluate() {
        return 0.0; // Evaluación futura
    }
}