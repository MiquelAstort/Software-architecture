package org.example;

public class Min extends Function {
    public Min(String coordinate, String range) {
        super(coordinate, range);
    }

    @Override
    public Double evaluate() {
        return 0.0; // Evaluación futura
    }
}
