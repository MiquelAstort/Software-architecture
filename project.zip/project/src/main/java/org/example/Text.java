package org.example;

public class Text extends Cell {
    public Text(String coordinate, String content) {
        super(coordinate, content);
    }

    @Override
    public String evaluate() {
        return content;
    }
}