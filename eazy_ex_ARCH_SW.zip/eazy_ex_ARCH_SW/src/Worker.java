public class Worker {
    public String name;
    public double salary;
    public double complement;
    public double taxes;
    public Worker(String name, double salary, double complement, double taxes) {
        this.name = name;
        this.salary = salary;
        this.complement = complement;
        this.taxes = taxes;
    }


}

